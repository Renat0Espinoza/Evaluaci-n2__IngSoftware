package com.example.Eval2.Entidad;

public enum TamanoMueble {
    GRANDE,
    MEDIANO,
    PEQUEÑO
}