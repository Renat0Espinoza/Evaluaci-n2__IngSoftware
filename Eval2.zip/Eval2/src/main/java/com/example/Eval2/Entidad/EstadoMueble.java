package com.example.Eval2.Entidad;

public enum EstadoMueble {
    ACTIVO,
    INACTIVO
}